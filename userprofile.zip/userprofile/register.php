<!DOCTYPE html>
<html lang="en-US">
  <head>
  <title>Task</title>
  <link rel="stylesheet" href="libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="libs/style.css">
  </head>
  <h1>Register</h1>
<div class="reg-input-field">
        <h3>Please Fill-out All Fields</h3>
        <form method="post" action="#" >
          <div class="form-group">
            <label>Fullname</label>
            <input type="text" class="form-control" name="fname" style="width:20em;" placeholder="Enter your Fullname" required />
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input type="tel" class="form-control" name="phone" style="width:20em;" placeholder="Enter your phone" required pattern="[0-9]{10}" />
          </div>
          <div class="form-group">
            <label>DOB</label>
            <input type="date" class="form-control" id="dob" name="dob" style="width:20em;" placeholder="Enter your Date OF Birth">
            <span id="age-validation"></span>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" name="user" style="width:20em;" placeholder="Enter your Email">
          </div><div class="form-group">
            <label>Password</label>
            <input type="Password" class="form-control" id="password" name="pass" style="width:20em;" required  placeholder="Enter your Password">
            <span id="password-validation"></span>
          </div>
          <div class="form-group">
            <input type="submit" id="submit-btn" name="submit" class="btn btn-primary submitBtn" style="width:20em; margin:0;" /><br><br>
             <center>
             <a href="index.php">LogIn</a>
           </center>
          </div>
        </form>
      </div>
      <script>
      const dobInput = document.getElementById('dob');
      const ageValidation = document.getElementById('age-validation');
      const passwordInput = document.getElementById('password');
      const passwordValidation = document.getElementById('password-validation');
      const submitBtn = document.getElementById('submit-btn');

      dobInput.addEventListener('input', () => {
        const dob = new Date(dobInput.value);
        const ageInMilliseconds = Date.now() - dob.getTime();
        const ageInYears = ageInMilliseconds / 1000 / 60 / 60 / 24 / 365;

        if (ageInYears < 18) {
          ageValidation.textContent = 'You must be 18 or older to register';
          submitBtn.disabled = true;
        } else {
          ageValidation.textContent = '';
          submitBtn.disabled = false;
        }

        passwordInput.addEventListener('input', () => {
        const password = passwordInput.value;

        if (password.length < 8) {
          passwordValidation.textContent = 'Password must be at least 8 characters long';
          submitBtn.disabled = true;
        } else if (!/\d/.test(password) || !/[a-zA-Z]/.test(password) || !/\W/.test(password)) {
          passwordValidation.textContent = 'Password must contain special characters, numbers, and letters';
          submitBtn.disabled = true;
        } else {
          passwordValidation.textContent = '';
          submitBtn.disabled = false;
        }
      });

      });


      </script>
      </html>
      <?php
      include 'connection.php';
if(isset($_POST['submit'])){
$fname = $_POST['fname'];
$phone = $_POST['phone'];
$dob = $_POST['dob'];
$user = $_POST['user'];
$pass = $_POST['pass'];


  $query = "INSERT INTO users
                (username, password, full_name,phone,dob)
                VALUES ('".$user."','".$pass."','".$fname."','".$phone."','".$dob."')";
                mysqli_query($db,$query)or die ('Error in updating Database');
                ?>
                <script type="text/javascript">
            alert("Successfull Added.");
            window.location = "index.php";
        </script>
                <?php
}
      ?>